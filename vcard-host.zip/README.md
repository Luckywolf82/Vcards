# vCard Host

Dette repoet inneholder filer for å hoste vCard (.vcf) for Trygve Eiulf Waagen via GitHub Pages.

## Innhold
- `.nojekyll` – Slår av Jekyll-behandling på GitHub Pages.
- `index.html` – Enkel landingsside med knapp for nedlasting.
- `trygve.vcf` – Selve vCard-filen (UTF-8, v3.0).

## Publisering (GitHub Pages)
1. Opprett et public repo og last opp filene i rot.
2. Gå til **Settings → Pages**.
3. Under *Build and deployment*: **Source: Deploy from a branch**.
4. Velg **Branch: main** og **/ (root)** → **Save**.
5. Vent litt, siden blir tilgjengelig på `https://<brukernavn>.github.io/<repo>/`.

## NFC
Skriv NDEF‑URL til `https://<brukernavn>.github.io/<repo>/trygve.vcf` på NTAG215‑kortet for sømløs import på iPhone/Android.
